package test;

import org.example.Cow_and_Bull.Bot.Bull;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



public class Bull_test {
    private Bull bull ;

    @Before
    public void setUp() {
        bull = new Bull();
        int[] guess =        {1, 5, 3, 7};
        int[] secretMassiv = {1, 5, 3, 7};
        int secret = 4;

        bull.setGuess(guess);
        bull.setSecretMassiv(secretMassiv);
        bull.setSecret(secret);
        new Bull();
        bull.setCountBulls(0);
        //Чтобы проверить тест удалите два последних метода в bull//
    }

    @Test
    public void testCountBulls() {
        int expected = 4;
        int actual = bull.countBulls();

        Assert.assertEquals(expected, actual);
    }
}