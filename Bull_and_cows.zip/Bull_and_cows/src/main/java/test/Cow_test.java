package test;

import org.example.Cow_and_Bull.Bot.Cow;
import org.junit.Before;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

public class Cow_test {
    private Cow cow  = new Cow();;

    @Before
    public void setUp() {
        cow = new Cow();
    }

    @Test
    public void testCountCowsAndBulls() {
        int[] guess = {1, 2, 3, 4};
        int[] secretMassiv = {2, 4, 1, 3};

        cow.setGuess(guess);
        cow.setSecretMassiv(secretMassiv);

        int countCowsAndBulls = cow.countCowsAndBulls();

        assertEquals(4, countCowsAndBulls);
    }
}
