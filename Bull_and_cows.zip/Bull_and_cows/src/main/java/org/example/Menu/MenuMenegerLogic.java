package org.example.Menu;

import org.example.Bot.BotGame;
import org.example.Player.Players_game;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuMenegerLogic {


    GameRule rule = new GameRule();
    private int menu;


    public int getMenu() {
        return menu;
    }

    public int Menu() {
        Scanner in = new Scanner(System.in);

        try {
            menu = in.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Ошибка ввода. Пожалуйста, введите целое число:");
            in.nextLine();
            menu = Menu();
        }
        return menu;
    }

    public void MenuLogic(int menu) {
        if (menu == 1) {
            System.out.println("Одиночная игра с ботом");
            BotGame game = new BotGame();
        } else if (menu == 2) {
            System.out.println("Игра с человеком по локальной сети");
            Players_game game=new Players_game();
        } else if (menu == 3) {
            System.out.println("Правила игры\n");
            System.out.println(rule.getRule());
            MenuMeneger Menu = new MenuMeneger();
        } else if (menu == 4) {
            System.out.println("Выход");
        } else {
            System.out.println("Введен некорректный номер меню\n");
            MenuMeneger Menu = new MenuMeneger();
        }
    }

    public void MenuUGI() {
        System.out.println("_______________\u001B[1mМеню\u001B[0m_________________");
        System.out.println("------------------------------------");
        System.out.println("\u001B[1mДобро пожаловать в игру \"Быки и коровы\"\u001B[0m");
        System.out.println("------------------------------------");
        System.out.println("1. Игра с роботом");
        System.out.println("2. Игра с человеком по локальной сети");
        System.out.println("3. Правила");
        System.out.println("4. Выйти");
        System.out.println("------------------------------------");
        System.out.print("Выберите пункт меню: ");
    }
}