package org.example.Menu;

public class MenuMeneger {
MenuMenegerLogic menu = new MenuMenegerLogic();
public MenuMeneger(){
    menu.MenuUGI();
    menu.Menu();
    menu.MenuLogic(menu.getMenu());
}
}
