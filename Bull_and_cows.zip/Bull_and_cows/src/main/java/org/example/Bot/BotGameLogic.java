package org.example.Bot;

import org.example.Result.ResultBot;

import java.io.*;
import java.util.*;


public class BotGameLogic {


    private String temp;
    private int secret;

    private int shouldRepeat;
    private int[] secretMassiv;
    private int[] guess;
    private int[] usedGuess;


    public BotGameLogic() {
        readFromFile();
        guessplayer();
        guess = preobrasovatelil(temp);
        usedGuess = new int[secret];
        Arrays.fill(usedGuess, 0);
        writeToFile();

        ResultBot rel = new ResultBot(this); // Передаем экземпляр BotGameLogic в конструктор ResultBot
    }

    private String guessplayer() {
        Scanner in = new Scanner(System.in);
        boolean allowRepeatingNumbers = shouldRepeat == 1;

        while (true) {
            try {
                System.out.print("Введите ваш вариант числа - \n");
                temp = in.nextLine();

                // Проверка на наличие только цифр и игнорирование знаков + и -
                temp = temp.replaceAll("[^\\d]", "");

                // Проверка на длину числа
                if (secret != temp.length()) {
                    System.out.println("Неверное число. Пожалуйста, введите число длиной " + secret + " и повторите попытку.");
                    continue;
                }

                // Проверка на повторяющиеся цифры
                if (!allowRepeatingNumbers && hasRepeatingDigits(temp)) {
                    System.out.println("Повторяющиеся цифры запрещены. Пожалуйста, введите число без повторов и повторите попытку.");
                    continue;
                }

                // Проверка на наличие только цифр без пробелов
                if (!isValidNumber(temp)) {
                    System.out.println("Неверный формат числа. Пожалуйста, введите число без пробелов и повторите попытку.");
                    continue;
                }

                // Продолжайте добавлять дополнительные проверки по вашему усмотрению

                break;
            } catch (InputMismatchException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите число.");
                in.nextLine();
            }
        }

        return temp;
    }

    private boolean isValidNumber(String number) {
        return number.matches("[0-9]+");
    }

    private boolean hasRepeatingDigits(String number) {
        Set<Character> uniqueDigits = new HashSet<>();

        for (char digit : number.toCharArray()) {
            if (!uniqueDigits.add(digit)) {
                return true; // Если цифра уже присутствует в uniqueDigits, значит есть повтор
            }
        }

        return false; // Нет повторяющихся цифр
    }


    private int[] preobrasovatelil(String temp) {
        guess = new int[secret];
        for (int i = 0; i < secret; i++) {
            guess[i] = temp.charAt(i) - '0';
        }
        return guess;
    }

    public void readFromFile() {
        String fileName = "Settins.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            secret = Integer.parseInt(secretLine);

            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            secretMassiv = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                secretMassiv[i] = Integer.parseInt(secretMassiveValues[i]);
            }

            String shouldRepeatLine = bufferedReader.readLine();
            shouldRepeat = Integer.parseInt(shouldRepeatLine);

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void writeToFile() {
        String fileName = "Botgamelogic.txt";
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));


            for (int i : guess) {
                writer.print(i + " ");
            }
            writer.println();

            writer.close();
        } catch (IOException e) {
            System.out.println("Ошибка при записи данных в файл.");
            e.printStackTrace();
        }
    }


}