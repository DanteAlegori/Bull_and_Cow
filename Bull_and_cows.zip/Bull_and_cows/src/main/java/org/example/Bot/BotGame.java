package org.example.Bot;

import org.example.Setting.Setting_Bot;

public class BotGame {



    public  BotGame() {
        Setting_Bot setting = new Setting_Bot();

         BotGameLogic logic =new  BotGameLogic();

    }
}
