package org.example.Player;

import org.example.Setting.Setting_Player;

public class Players_game {
    public Players_game() {
        Setting_Player sey = new Setting_Player();

        Players_game_logic logic = new Players_game_logic();
    }

}
