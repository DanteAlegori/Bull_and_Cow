package org.example;


import org.example.Game.Game;

public class Main {
    public static void main(String[] args) {
       Game run=new Game();
        }
    }
