package org.example.Game;

import org.example.Menu.MenuMeneger;

public class Game {
    MenuMeneger Menu= new MenuMeneger();


}
