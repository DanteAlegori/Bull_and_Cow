package org.example.Setting;

import java.util.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Setting_Player {
    private static Setting_Bot Setting;
    private int secret;
    private int shouldRepeat;
    private int[] secretMassiv;
    private int[] used;
    private int index;

    private String temp;

    private int[] guess1;
    private int[] guess2;

    public Setting_Player() {
        shouldRepeat();
        Secret();
        System.out.println("Игрок 1 загадайте Игроку 2 число");
        guessplayer();
        initializeArrays();
        guess1 = preobrasovatelil(temp);
        System.out.println("Игрок 2 загадайте Игроку 1 число");
        guessplayer();
        initializeArrays();
        guess2 = preobrasovatelil1(temp);
        writeToFile(); // Перенесен вызов writeToFile() здесь
        writeToFile1(); // Перенесен вызов writeToFile() здесь

        writeToFile2(); // Перенесен вызов writeToFile() здесь
    }

    public static Setting_Bot getSetting() {
        if (Setting == null) {
            Setting = new Setting_Bot();
        }
        return Setting;
    }

    public int Secret() {
        System.out.println("\u001B[37m\u001B[1mВведите длину загадаемого числа:\u001B[0m");
        Scanner in = new Scanner(System.in);
        boolean validInput = false;
        do {
            try {
                if (in.hasNextInt()) {
                    secret = in.nextInt();
                    if (secret > 0 && (shouldRepeat == 1 || secret <= 10)) {
                        validInput = true;
                    } else {
                        System.out.println("Ошибка ввода. Пожалуйста, введите положительное целое число от 1 до 10 :");
                    }
                } else {
                    String input = in.next();
                    System.out.println("Ошибка ввода. Пожалуйста, введите целое число:");
                }
            } catch (NoSuchElementException | IllegalStateException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите целое число:");
                in = new Scanner(System.in); // Создаем новый объект Scanner для предотвращения зацикливания
            }
        } while (!validInput);

        return secret;
    }

    public int shouldRepeat() {
        Scanner in = new Scanner(System.in);
        do {
            try {
                System.out.println("\u001B[37m\u001B[1mДолжны ли числа повторяться? (Введите 1 для Да, 2 для Нет)\u001B[0m");
                shouldRepeat = in.nextInt();
                if (shouldRepeat != 1 && shouldRepeat != 2) {
                    System.out.println("Неверный ввод. Пожалуйста, введите 1 или 2:");
                }
            } catch (InputMismatchException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите число 1 или 2:");
                in.nextLine();
            } catch (NoSuchElementException | IllegalStateException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите число 1 или 2:");
                in = new Scanner(System.in); // Создаем новый объект Scanner для предотвращения зацикливания
            }
        } while (shouldRepeat != 1 && shouldRepeat != 2);

        return shouldRepeat;
    }

    public void initializeArrays() {
        if (secretMassiv == null) {
            secretMassiv = new int[secret];
            used = new int[10];
            index = 0;
        }
    }

    private String guessplayer() {
        Scanner in = new Scanner(System.in);
        boolean allowRepeatingNumbers = shouldRepeat == 1;

        while (true) {
            try {
                System.out.print("Введите ваш вариант числа - \n");
                temp = in.nextLine();

                // Проверка на наличие только цифр и игнорирование знаков + и -
                temp = temp.replaceAll("[^\\d]", "");

                // Проверка на длину числа
                if (secret != temp.length()) {
                    System.out.println("Неверное число. Пожалуйста, введите число длиной " + secret + " и повторите попытку.");
                    continue;
                }

                // Проверка на повторяющиеся цифры
                if (!allowRepeatingNumbers && hasRepeatingDigits(temp)) {
                    System.out.println("Повторяющиеся цифры запрещены. Пожалуйста, введите число без повторов и повторите попытку.");
                    continue;
                }

                // Проверка на наличие только цифр без пробелов
                if (!isValidNumber(temp)) {
                    System.out.println("Неверный формат числа. Пожалуйста, введите число без пробелов и повторите попытку.");
                    continue;
                }

                // Продолжайте добавлять дополнительные проверки по вашему усмотрению

                break;
            } catch (InputMismatchException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите число.");
                in.nextLine();
            }
        }

        return temp;
    }


    private boolean isValidNumber(String number) {
        return number.matches("[0-9]+");
    }

    private boolean hasRepeatingDigits(String number) {
        Set<Character> uniqueDigits = new HashSet<>();

        for (char digit : number.toCharArray()) {
            if (!uniqueDigits.add(digit)) {
                return true; // Если цифра уже присутствует в uniqueDigits, значит есть повтор
            }
        }

        return false; // Нет повторяющихся цифр
    }

    private int[] preobrasovatelil(String temp) {
        guess1 = new int[secret];
        for (int i = 0; i < secret; i++) {
            guess1[i] = temp.charAt(i) - '0';
        }
        return guess1;
    }

    private int[] preobrasovatelil1(String temp) {
        guess2 = new int[secret];
        for (int i = 0; i < secret; i++) {
            guess2[i] = temp.charAt(i) - '0';
        }
        return guess2;
    }


    public  void writeToFile() {
        String fileName = "Settins_Player.txt";
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));

            writer.println(secret);

            writer.println(shouldRepeat);

            writer.close();
        } catch (IOException e) {
            System.out.println("Ошибка при записи данных в файл.");
            e.printStackTrace();
        }
    }


    public void writeToFile1() {
        String fileName = "Player1_secret.txt";
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));


            for (int i : guess1) {
                writer.print(i + " ");
            }
            writer.println();

            writer.close();
        } catch (IOException e) {
            System.out.println("Ошибка при записи данных в файл.");
            e.printStackTrace();
        }
    }

    public void writeToFile2() {
        String fileName = "Player2_secret.txt";
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));


            for (int i : guess2) {
                writer.print(i + " ");
            }
            writer.println();

            writer.close();
        } catch (IOException e) {
            System.out.println("Ошибка при записи данных в файл.");
            e.printStackTrace();
        }
    }

}

