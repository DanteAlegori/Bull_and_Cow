package org.example.Setting;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Setting_Bot {
    private static Setting_Bot Setting;
    private int secret;
    private int shouldRepeat;
    private int[] secretMassiv;
    private int[] used;
    private int index;



    public Setting_Bot() {
        shouldRepeat();
        Secret();
        initializeArrays();
        generateSecretMassive();
        writeToFile(); // Перенесен вызов writeToFile() здесь
    }

    public static Setting_Bot getSetting() {
        if (Setting == null) {
            Setting = new Setting_Bot();
        }
        return Setting;
    }

    public int Secret() {
        System.out.println("\u001B[37m\u001B[1mВведите длину загаданного числа:\u001B[0m");
        Scanner in = new Scanner(System.in);
        boolean validInput = false;
        do {
            try {
                if (in.hasNextInt()) {
                    secret = in.nextInt();
                    if (secret > 0 && (shouldRepeat == 1 || secret <= 10)) {
                        validInput = true;
                    } else {
                        System.out.println("Ошибка ввода. Пожалуйста, введите положительное целое число от 1 до 10 :");
                    }
                } else {
                    String input = in.next();
                    System.out.println("Ошибка ввода. Пожалуйста, введите целое число:");
                }
            } catch (NoSuchElementException | IllegalStateException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите целое число:");
                in = new Scanner(System.in); // Создаем новый объект Scanner для предотвращения зацикливания
            }
        } while (!validInput);

        return secret;
    }

    public int shouldRepeat() {
        Scanner in = new Scanner(System.in);
        do {
            try {
                System.out.println("\u001B[37m\u001B[1mДолжны ли числа повторяться? (Введите 1 для Да, 2 для Нет)\u001B[0m");
                shouldRepeat = in.nextInt();
                if (shouldRepeat != 1 && shouldRepeat != 2) {
                    System.out.println("Неверный ввод. Пожалуйста, введите 1 или 2:");
                }
            } catch (InputMismatchException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите число 1 или 2:");
                in.nextLine();
            } catch (NoSuchElementException | IllegalStateException e) {
                System.out.println("Ошибка ввода. Пожалуйста, введите число 1 или 2:");
                in = new Scanner(System.in); // Создаем новый объект Scanner для предотвращения зацикливания
            }
        } while (shouldRepeat != 1 && shouldRepeat != 2);

        return shouldRepeat;
    }

    public void initializeArrays() {
        if (secretMassiv == null) {
            secretMassiv = new int[secret];
            used = new int[10];
            index = 0;
        }
    }

    public int[] generateSecretMassive() {
        while (index < secret) {
            int digit;
            if (index == 0) {
                digit = (int) (Math.random() * 9) + 1; // Генерация числа от 1 до 9 для первой позиции
            } else {
                digit = (int) (Math.random() * 10); // Генерация числа от 0 до 9 для остальных позиций
            }

            if (shouldRepeat == 2 && used[digit] == 0) {
                secretMassiv[index] = digit;
                used[digit]++;
                index++;
            } else if (shouldRepeat == 1) {
                secretMassiv[index] = digit;
                used[digit]++;
                index++;
            }
        }
        return secretMassiv;
    }

    public  void writeToFile() {
        String fileName = "Settins.txt";
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));

            writer.println(secret);

            for (int i : secretMassiv) {
                writer.print(i + " ");
            }
            writer.println();

            writer.println(shouldRepeat);

            writer.close();
        } catch (IOException e) {
            System.out.println("Ошибка при записи данных в файл.");
            e.printStackTrace();
        }
    }


}

