package org.example.Cow_and_Bull.Player;

import java.io.*;



public class Bull_Player1{
        private int countBulls;
        private int secret;
        private int[] secretMassiv;

        private int[] guess;
        int[] usedGuess = new int[10];
        int[] botsecret = new int[10];

        public Bull_Player1() {
            readFromFile();
            readFromFileS();
            readFromFileS1();
            countBulls();
            writeToFile();
        }

        public int countBulls() {
            for (int i = 0; i < secret; i++) {
                if (secretMassiv[i] == guess[i]) {
                    countBulls++;
                    usedGuess[guess[i]]--;
                    botsecret[secretMassiv[i]]--;
                }
            }
            return countBulls;
        }

        public void readFromFile() {
            String fileName = "Player_1.txt";
            try {
                FileReader fileReader = new FileReader(fileName);
                BufferedReader bufferedReader = new BufferedReader(fileReader);


                String secretMassiveLine = bufferedReader.readLine();
                String[] secretMassiveValues = secretMassiveLine.split(" ");
                guess = new int[secretMassiveValues.length];
                for (int i = 0; i < secretMassiveValues.length; i++) {
                    guess[i] = Integer.parseInt(secretMassiveValues[i]);
                }

                bufferedReader.close();

            } catch (IOException e) {
                System.out.println("Error reading data from the file.");
                e.printStackTrace();
            }
        }


        public void readFromFileS() {
            String fileName = "Player2_secret.txt";
            try {
                FileReader fileReader = new FileReader(fileName);
                BufferedReader bufferedReader = new BufferedReader(fileReader);



                String secretMassiveLine = bufferedReader.readLine();
                String[] secretMassiveValues = secretMassiveLine.split(" ");
                secretMassiv = new int[secretMassiveValues.length];
                for (int i = 0; i < secretMassiveValues.length; i++) {
                    secretMassiv[i] = Integer.parseInt(secretMassiveValues[i]);
                }

                bufferedReader.close();


            } catch (IOException e) {
                System.out.println("Ошибка при чтении данных из файла.");
                e.printStackTrace();
            }
        }
    public void readFromFileS1() {
        String fileName = "Settins_Player.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            secret = Integer.parseInt(secretLine);



            bufferedReader.close();


        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }
        public void writeToFile() {
            String fileName = "Bull_Player1.txt";
            PrintWriter writer = null;
            try {
                writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));


                writer.println(countBulls);

                writer.flush();
                writer.close();
            } catch (IOException e) {
                System.out.println("Ошибка при записи данных в файл.");
                e.printStackTrace();
            }
        }

    public boolean startedGame() {
            return true;
    }
}
