package org.example.Cow_and_Bull.Bot;

import java.io.*;

public class Bull {

    private int countBulls;
    private int secret;
    private int[] secretMassiv;

    private int[] guess;
    int[] usedGuess = new int[10];
    int[] botsecret = new int[10];

    public Bull() {
        readFromFile();
        readFromFileS();
        countBulls();
        writeToFile();

    }

    public int countBulls() {
        for (int i = 0; i < secret; i++) {
            if (secretMassiv[i] == guess[i]) {
                countBulls++;
                usedGuess[guess[i]]--;
                botsecret[secretMassiv[i]]--;
            }
        }
        return countBulls;
    }

    public void readFromFile() {
        String fileName = "Botgamelogic.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);


            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            guess = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                guess[i] = Integer.parseInt(secretMassiveValues[i]);
            }

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Error reading data from the file.");
            e.printStackTrace();
        }
    }


    public void readFromFileS() {
        String fileName = "Settins.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            secret = Integer.parseInt(secretLine);

            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            secretMassiv = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                secretMassiv[i] = Integer.parseInt(secretMassiveValues[i]);
            }

            bufferedReader.close();


            System.out.println();
        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void writeToFile() {
        String fileName = "Bull.txt";
        PrintWriter writer = null;
        try {
            writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)));


            writer.println(countBulls);

            writer.flush();
            writer.close();
        } catch (IOException e) {
            System.out.println("Ошибка при записи данных в файл.");
            e.printStackTrace();
        }
    }

    public void setGuess(int[] guess) {
        this.guess = guess;
    }

    public int[] getGuess() {
        return guess;
    }

    public void setSecretMassiv(int[] secretMassiv) {
        this.secretMassiv = secretMassiv;
    }

    public int[] getSecretMassiv() {
        return secretMassiv;
    }

    public void setSecret(int secret) {
        this.secret = secret;
    }

    public int getSecret() {
        return secret;
    }
    public void setCountBulls(int countBulls) {
        this.countBulls = countBulls;
    }
}
