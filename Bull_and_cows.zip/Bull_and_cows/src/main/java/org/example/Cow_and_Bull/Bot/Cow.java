package org.example.Cow_and_Bull.Bot;

import org.example.Bot.BotGameLogic;
import org.example.Setting.Setting_Bot;

import java.io.*;
import java.util.HashSet;

public class Cow {
    private BotGameLogic logic;
    private Setting_Bot setting;

    private int countCows;
    private int secret;

    private int[] guess;

    private int[] secretMassiv;

    public Cow() {
        readFromFiles();
        readFromFile();
        countCows = countCowsAndBulls();
        writeToFile(countCows);
    }

    public void readFromFiles() {
        String fileName = "Settins.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            secret = Integer.parseInt(secretLine);
            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            secretMassiv = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                secretMassiv[i] = Integer.parseInt(secretMassiveValues[i]);
            }
            bufferedReader.close();

            System.out.println();
        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFile() {
        String fileName = "Botgamelogic.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            guess = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                guess[i] = Integer.parseInt(secretMassiveValues[i]);
            }

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Error reading data from the file.");
            e.printStackTrace();
        }
    }

    public int countCowsAndBulls() {
        int countBulls = 0;
        int countCows = 0;
        HashSet<Integer> foundBullPositions = new HashSet<>();
        HashSet<Integer> foundCowPositions = new HashSet<>();

        for (int i = 0; i < guess.length; i++) {
            if (guess[i] == secretMassiv[i]) {
                countBulls++;
                foundBullPositions.add(i);
            }
        }

        for (int i = 0; i < guess.length; i++) {
            if (!foundBullPositions.contains(i)) {
                for (int j = 0; j < secretMassiv.length; j++) {
                    if (guess[i] == secretMassiv[j] && !foundBullPositions.contains(j) && !foundCowPositions.contains(j)) {
                        countCows++;
                        foundCowPositions.add(j);
                        break;
                    }
                }
            }
        }



        return countCows;
    }

    public void writeToFile(int countCows) {
        String fileName = "Cow.txt";
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(fileName)))) {
            writer.println(countCows);
        } catch (IOException e) {
            System.out.println("Ошибка при записи данных в файл.");
            e.printStackTrace();
        }
    }

    public void setGuess(int[] guess) {
        this.guess = guess;
    }

    public int[] getGuess() {
        return guess;
    }

    public void setSecretMassiv(int[] secretMassiv) {
        this.secretMassiv = secretMassiv;
    }

    public int[] getSecretMassiv() {
        return secretMassiv;
    }
}






