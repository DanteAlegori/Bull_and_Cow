package org.example.Result;

import org.example.Bot.BotGameLogic;
import org.example.Cow_and_Bull.Bot.Bull;
import org.example.Cow_and_Bull.Bot.Cow;
import org.example.Menu.MenuMeneger;

import java.io.*;
import java.util.Arrays;


public class ResultBot {
    private BotGameLogic botGameLogic;
    Bull sd = new Bull();
    Cow ds = new Cow();


    private int[] secretMassiv;
    int cows;
    int bulls;


    public ResultBot(BotGameLogic botGameLogic) {
        readFromFile();
        readFromFileCow();
        readFromFileBull();
        results(bulls);

    }

    public void readFromFileCow() {
        String fileName = "Cow.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            cows = Integer.parseInt(secretLine);

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFileBull() {
        String fileName = "Bull.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            bulls = Integer.parseInt(secretLine);

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFile() {
        String fileName = "Settins.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            int secret = Integer.parseInt(secretLine);

            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            secretMassiv = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                secretMassiv[i] = Integer.parseInt(secretMassiveValues[i]);
            }

            bufferedReader.close();


            System.out.println();
        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void results(int bulls) {
        if (this.bulls == secretMassiv.length) {
            System.out.println("\u001B[32mПоздравляю! Вы угадали число " +
                    Arrays.toString(secretMassiv) + " Поздравляем!\u001B[0m");
            System.out.println("\u001B[32mВы будете возвращены в меню\n\u001B[0m");

            MenuMeneger menu = new MenuMeneger();
        } else {
            System.out.println("\u001B[33mБыки: " + this.bulls + "\u001B[0m");
            System.out.println("\u001B[33mКоровы: " + cows + "\u001B[0m");
            BotGameLogic bbb = new BotGameLogic();
        }
    }


}