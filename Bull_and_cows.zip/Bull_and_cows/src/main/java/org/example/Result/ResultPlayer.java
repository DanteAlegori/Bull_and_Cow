package org.example.Result;

import org.example.Bot.BotGameLogic;
import org.example.Cow_and_Bull.Bot.Bull;
import org.example.Cow_and_Bull.Bot.Cow;
import org.example.Cow_and_Bull.Player.Bull_Player1;
import org.example.Cow_and_Bull.Player.Bull_Player2;
import org.example.Cow_and_Bull.Player.Cow_Player1;
import org.example.Cow_and_Bull.Player.Cow_Player2;
import org.example.Menu.MenuMeneger;
import org.example.Player.Players_game_logic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class ResultPlayer {
    Bull_Player1 p1 = new Bull_Player1();

    Bull_Player2 p2 = new Bull_Player2();

    Cow_Player1 c1 = new Cow_Player1();

    Cow_Player2 c2 = new Cow_Player2();


    private int[] secretMassiv1;
    private int[] secretMassiv2;
    int cows1;
    int cows2;
    int bulls1;
    int bulls2;


    public ResultPlayer() {
        readFromFileCow1();
        readFromFileCow2();
        readFromFileBull1();
        readFromFileBull2();
        readFromFile1();
        readFromFile1_1();
        readFromFile1_2();
        results();

    }

    public void readFromFileCow1() {
        String fileName = "Cow_Player1.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            cows1 = Integer.parseInt(secretLine);

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFileCow2() {
        String fileName = "Cow_Player2.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            cows2 = Integer.parseInt(secretLine);

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFileBull1() {
        String fileName = "Bull_Player1.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            bulls1 = Integer.parseInt(secretLine);

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFileBull2() {
        String fileName = "Bull_Player2.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            bulls2 = Integer.parseInt(secretLine);

            bufferedReader.close();

        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFile1() {
        String fileName = "Settins_Player.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String secretLine = bufferedReader.readLine();
            int secret = Integer.parseInt(secretLine);


            bufferedReader.close();



        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFile1_1() {
        String fileName = "Player1_secret.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);


            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            secretMassiv1 = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                secretMassiv1[i] = Integer.parseInt(secretMassiveValues[i]);
            }

            bufferedReader.close();



        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void readFromFile1_2() {
        String fileName = "Player2_secret.txt";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);


            String secretMassiveLine = bufferedReader.readLine();
            String[] secretMassiveValues = secretMassiveLine.split(" ");
            secretMassiv2 = new int[secretMassiveValues.length];
            for (int i = 0; i < secretMassiveValues.length; i++) {
                secretMassiv2[i] = Integer.parseInt(secretMassiveValues[i]);
            }

            bufferedReader.close();



        } catch (IOException e) {
            System.out.println("Ошибка при чтении данных из файла.");
            e.printStackTrace();
        }
    }

    public void results() {
        boolean isPlayer1Started= true;
        boolean isPlayer2Started = false;
        if (bulls1 == secretMassiv1.length && bulls2 == secretMassiv2.length) {
            System.out.println("\u001B[31mНичья!\u001B[0m");
            System.out.println("\u001B[32mВы будете возвращены в меню\u001B[0m");
            MenuMeneger menu = new MenuMeneger();
        } else if (bulls1 == secretMassiv1.length && !isPlayer1Started) {
            System.out.println("\u001B[31mПобедил игрок 1!\u001B[0m");
            System.out.println("\u001B[32mВы будете возвращены в меню\u001B[0m");
            MenuMeneger menu = new MenuMeneger();
        } else if (bulls2 == secretMassiv2.length && !isPlayer2Started) {
            System.out.println("\u001B[31mПобедил игрок 2!\u001B[0m");
            System.out.println("\u001B[32mВы будете возвращены в меню\u001B[0m");
            MenuMeneger menu = new MenuMeneger();
        } else {
            System.out.println("\u001B[33mБыки игрок 1: " + bulls1 + "\u001B[0m");
            System.out.println("\u001B[33mКоровы игрок 1: " + cows1 + "\u001B[0m");
            System.out.println("\u001B[33mБыки игрок 2: " + bulls2 + "\u001B[0m");
            System.out.println("\u001B[33mКоровы игрок 2: " + cows2 + "\u001B[0m");
            Players_game_logic logic = new Players_game_logic();
        }
    }
}



